#!/usr/bin/env bash
# Fetches sherpa-onnx (native libs + Kotlin API) so the app can run the offline Tamil engine.
# Used by the GitHub workflow; you can also run it locally before building in Android Studio.
# Needs: gh (GitHub CLI, logged in or GH_TOKEN set), git, tar.
set -euo pipefail
REPO=k2-fsa/sherpa-onnx
TMP=$(mktemp -d)

TAG=$(gh release list --repo "$REPO" --exclude-pre-releases --limit 40 --json tagName -q '.[].tagName' \
      | grep -E '^v[0-9]+\.[0-9]+\.[0-9]+$' | sed -n 1p)
echo "Using sherpa-onnx $TAG"

gh release download "$TAG" --repo "$REPO" --pattern "sherpa-onnx-${TAG}-android.tar.bz2" --dir "$TMP"
tar xjf "$TMP"/sherpa-onnx-"${TAG}"-android.tar.bz2 -C "$TMP"

LIBDIR=$(find "$TMP" -type d -name arm64-v8a | sed -n 1p)
[ -n "$LIBDIR" ] || { echo "arm64-v8a libs not found in release"; exit 1; }
mkdir -p app/src/main/jniLibs/arm64-v8a
cp "$LIBDIR"/*.so app/src/main/jniLibs/arm64-v8a/

git clone --depth 1 --branch "$TAG" "https://github.com/$REPO.git" "$TMP/src"
mkdir -p app/src/main/java/com/k2fsa/sherpa/onnx
cp "$TMP"/src/sherpa-onnx/kotlin-api/*.kt app/src/main/java/com/k2fsa/sherpa/onnx/   # last step: enables the real engine
echo "sherpa-onnx ready"
