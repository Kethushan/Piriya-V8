# Piriya V8
Tamil-first Android voice assistant with an always-on "Piriya" wake word.

## GitHub ல APK build பண்ண
1. இந்த folder ன் உள்ளடக்கம் (build.gradle.kts, app/, .github/ ...) repo ன் **root** ல இருக்கணும்.
2. GitHub ல push பண்ணுங்க -> **Actions** tab -> "Build Piriya APK" ஓடும்.
3. முடிஞ்சதும் run ஐ திறந்து **Artifacts -> Piriya-debug-apk** download பண்ணி, zip ஐ extract செய்து APK install பண்ணுங்க.

## Features
- Wake word: "Piriya" (background foreground-service). "Piriya youtube open" மாதிரி ஒரே வாக்கியத்திலும் வேலை செய்யும்.
- Tamil speech recognition (ta-LK) + Tamil TTS
- YouTube / Chrome / any installed app, Camera, Flashlight
- WiFi / Bluetooth / Display / Settings shortcuts, Volume, Alarm, Timer, Time
- Contact name சொல்லி call, Web search

## Own offline Tamil engine (no Google speech)
- GitHub build தானாவே `fetch-sherpa.sh` ஓட்டி sherpa-onnx (native libs + Kotlin API) சேர்க்கும். Fail ஆனாலும் build ஆகும், அப்போ engine switch disabled ஆ இருக்கும்.
- App ல **⬇ Tamil engine download** (375 MB, Wi-Fi) -> முடிஞ்சதும் **Own offline Tamil engine** switch ON.
- Model: Whisper-small Tamil (IIT Madras Speech Lab fine-tune, INT8) - `ippocode/indic-asr-onnx` on Hugging Face, Apache-2.0.
- Mic-ஐ app தானே எடுக்கும் (voice-activity detection), ஒவ்வொரு வாக்கியமும் phone ல offline ஆ decode ஆகும். Wake word "Piriya" இதே text ல தேடும்.
- ~4 GB RAM phone நல்லது; decode ஒவ்வொரு வாக்கியத்துக்கும் சில விநாடி ஆகலாம்.

## V6 - புதுசா என்ன
- **Default assistant:** Phone Settings -> Default apps -> Digital assistant app -> **Piriya**. (App ல ⭐ Assistant button). அப்புறம் power button long-press பண்ணா Piriya "சொல்லுங்க" னு கேட்கும்.
- **Voice control of other apps:** App ல ♿ Access -> Piriya ஐ ON. Commands: "back", "home", "recent apps", "notifications", "scroll down/up", "screenshot", "tap <button name>" (உதா: "Piriya tap send").
- **AI brain:** App ல 🧠 AI key -> Anthropic API key paste. Built-in commands (call, alarm, app open...) offline ஆவே வேலை செய்யும்; மற்ற கேள்விகள் மட்டும் AI க்கு போகும் (internet + API செலவு). Key காலியா விட்டா AI OFF.
- Key இந்த phone ல மட்டும் இருக்கும் (allowBackup OFF பண்ணியிருக்கு). GitHub ல key போடாதீங்க.
- **Piriya Home (launcher):** App ல 🏠 Home -> Piriya ஐ default Home app ஆ select பண்ணுங்க. Clock, app search, app grid, 🎙 Piriya button. App மேல long-press = App info. திரும்ப மாத்தணும்னா Settings -> Default apps -> Home app.
- **Voice setup:** "Piriya setup" னு சொல்லுங்க -> அடுத்து ON பண்ண வேண்டிய Settings screen தானா திறக்கும், என்ன தட்டணும்னு சொல்லும். முடிஞ்சதும் திரும்ப "Piriya setup" சொல்லுங்க. (Android இந்த permission களை app தானே ON பண்ண விடாது - ஒரு தடவை மட்டும் தட்டணும்.)
- Phone restart ஆன பிறகு ஒரு தடவை unlock பண்ணுங்க; Piriya Home/Accessibility மூலமா wake word தானா start ஆகும்.

## Not done yet
- Full custom ROM (AOSP) - இது app project க்கு வெளியே தனி build.

## Notes
- Default engine is the phone's Google speech service (needs internet). Switch to the own offline engine above to avoid it.
- Wake word is a speech-recognition loop, not a dedicated wake-word engine: uses more battery, and a short gap between listening rounds is possible.
- Never hard-code private API keys into the app.
