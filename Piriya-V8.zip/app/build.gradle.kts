import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.piriya.assistant"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.piriya.assistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 8
        versionName = "8.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
}

// The offline Tamil engine needs sherpa-onnx (fetched by the GitHub workflow / fetch-sherpa.sh).
// If those files are not there, a stub is compiled instead and the app just uses Google speech.
val hasSherpa = file("src/main/java/com/k2fsa/sherpa/onnx/OfflineRecognizer.kt").exists()
android {
    sourceSets {
        getByName("main") {
            java.srcDir(if (hasSherpa) "src/engine-real/kotlin" else "src/engine-stub/kotlin")
        }
    }
}
