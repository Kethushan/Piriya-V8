package com.piriya.assistant

import android.content.Context
import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineWhisperModelConfig

/** Real engine: sherpa-onnx + Tamil Whisper. Compiled only when the build fetched sherpa-onnx (see workflow). */
object TamilAsr {
    const val AVAILABLE = true
    private var rec: OfflineRecognizer? = null

    @Synchronized
    fun load(ctx: Context): Boolean {
        if (rec != null) return true
        return try {
            val d = ModelStore.dir(ctx).absolutePath
            val cfg = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    whisper = OfflineWhisperModelConfig(
                        encoder = "$d/encoder.int8.onnx",
                        decoder = "$d/decoder.int8.onnx",
                        language = "ta",
                        task = "transcribe",
                    ),
                    tokens = "$d/tokens.txt",
                    numThreads = 2,
                    modelType = "whisper",
                )
            )
            rec = OfflineRecognizer(config = cfg)
            true
        } catch (t: Throwable) {
            false   // missing native lib for this CPU, out of memory, bad model files ...
        }
    }

    @Synchronized
    fun recognize(samples: FloatArray): String {
        val r = rec ?: return ""
        val s = r.createStream()
        return try {
            s.acceptWaveform(samples, 16000)
            r.decode(s)
            r.getResult(s).text.trim()
        } catch (t: Throwable) {
            ""
        } finally {
            s.release()
        }
    }

    @Synchronized
    fun release() {
        rec?.release()
        rec = null
    }
}
