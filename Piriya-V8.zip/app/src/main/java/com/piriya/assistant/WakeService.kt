package com.piriya.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import java.util.Locale

/**
 * Always-listening foreground service. Says "Piriya" -> she answers "சொல்லுங்க" and runs the next command.
 * "Piriya youtube open" in one sentence also works.
 */
class WakeService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_STOP = "com.piriya.assistant.STOP"
        private const val CH_RUN = "piriya_run"
        private const val CH_PROMPT = "piriya_prompt"

        /** Mutes notification/system streams while listening so the recognizer's start "beep" is silent. */
        private const val MUTE_BEEP = true

        @Volatile var instance: WakeService? = null
        val isRunning: Boolean get() = instance != null

        fun start(ctx: Context) {
            try {
                ctx.startForegroundService(Intent(ctx, WakeService::class.java))
            } catch (e: Exception) {
                notifyTapToStart(ctx)
            }
        }

        /** Starts the wake word if the user wants it, has given the mic permission and it is not already running. */
        fun ensureRunning(ctx: Context) {
            if (isRunning) return
            if (!ctx.getSharedPreferences("piriya", Context.MODE_PRIVATE).getBoolean("wake", true)) return
            if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
            start(ctx)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, WakeService::class.java))
        }

        /** Android blocks starting a microphone service from the background (e.g. after boot) - ask for one tap instead. */
        fun notifyTapToStart(ctx: Context) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH_PROMPT, "Piriya start", NotificationManager.IMPORTANCE_HIGH))
            val pi = PendingIntent.getActivity(
                ctx, 1,
                Intent(ctx, MainActivity::class.java).putExtra("start_wake", true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(ctx, CH_PROMPT)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("Piriya")
                .setContentText("Wake word ON பண்ண இங்க tap பண்ணுங்க")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(2, n)
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var running = false
    private var speaking = false
    private var commandMode = false
    private var handled = false
    private var onSpeakDone: (() -> Unit)? = null
    private var overlay: View? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private var offline: OfflineListener? = null
    @Volatile private var useOffline = false
    @Volatile private var resumeAt = 0L
    val isOffline: Boolean get() = useOffline

    private val startRunnable = Runnable { startListening() }
    private val cmdTimeout = Runnable { commandMode = false }
    private val speakGuard = Runnable { finishSpeak() }

    override fun onCreate() {
        super.onCreate()
        instance = this
        tts = TextToSpeech(this, this)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences("piriya", MODE_PRIVATE).edit().putBoolean("wake", false).apply()
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            goForeground()
        } catch (e: Exception) {
            notifyTapToStart(this)
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) {
            running = true
            acquireWakeLock()
            addOverlay()
            muteBeep(true)
            chooseEngine()
        }
        return START_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_RUN, "Piriya listening", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, WakeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CH_RUN)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Piriya")
            .setContentText("“Piriya” னு சொல்லுங்க — கேட்டுக்கொண்டிருக்கிறேன்")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_notif), "Stop", stopPi).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    // ---------- listening loop ----------
    private fun listenSoon(ms: Long) {
        main.removeCallbacks(startRunnable)
        main.postDelayed(startRunnable, ms)
    }

    /** Own Tamil engine (offline Whisper) if downloaded + enabled, otherwise Google speech recognizer. */
    private fun chooseEngine() {
        val want = getSharedPreferences("piriya", MODE_PRIVATE).getBoolean("engine_offline", false)
        if (want && TamilAsr.AVAILABLE && ModelStore.ready(this)) {
            Thread {
                val ok = TamilAsr.load(this)
                main.post {
                    if (!running) return@post
                    if (ok) { useOffline = true; startOffline() } else { useOffline = false; listenSoon(300) }
                }
            }.start()
        } else listenSoon(300)
    }

    private fun startOffline() {
        if (offline != null) return
        offline = OfflineListener(
            isCommand = { commandMode },
            isPaused = { speaking || SystemClock.elapsedRealtime() < resumeAt },
            onText = { t -> if (running) processHeard(listOf(t)) }
        ).also { it.start() }
    }

    private fun enterCommandMode() {
        commandMode = true
        main.removeCallbacks(cmdTimeout)
        main.postDelayed(cmdTimeout, 9000)
    }

    /** Called by the app's mic button so both don't fight over the microphone. */
    fun pauseFor(ms: Long) {
        resumeAt = SystemClock.elapsedRealtime() + ms
        rec?.cancel()
        commandMode = false
        if (!useOffline) listenSoon(ms)
    }

    /** Mic button while the service is running: answer "சொல்லுங்க" and treat the next sentence as a command. */
    fun armCommand() {
        main.post { say("சொல்லுங்க") { enterCommandMode(); listenSoon(0) } }
    }

    private fun startListening() {
        if (useOffline || !running || speaking) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf(); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { listenSoon(5000); return }
        handled = false
        rec?.destroy()
        val r = Recog.create(this)
        r.setRecognitionListener(listener)
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ta-LK")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ta-LK")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        })
        rec = r
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(b: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}

        override fun onResults(b: Bundle?) {
            if (!onHeard(b)) {
                commandMode = false
                listenSoon(200)
            }
        }

        override fun onError(e: Int) {
            if (handled) return
            if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stopSelf(); return }
            commandMode = false // silence while waiting for a command -> back to wake-word mode
            listenSoon(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200 else 300)
        }
    }

    private fun onHeard(b: Bundle?): Boolean {
        if (handled) return true
        val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (list.isNullOrEmpty()) return false
        return processHeard(list)
    }

    /** @return true when the text was consumed (wake word or command found). Used by both engines. */
    private fun processHeard(list: List<String>): Boolean {
        if (commandMode) {
            handled = true
            val heard = list.first()
            runCommand(Commands.stripWake(heard).ifBlank { heard })
            return true
        }
        val hit = list.firstOrNull { Commands.hasWake(it) } ?: return false
        handled = true
        val cmd = Commands.stripWake(hit)
        if (cmd.isBlank()) {
            say("சொல்லுங்க") { enterCommandMode(); listenSoon(0) }
        } else runCommand(cmd)
        return true
    }

    private fun runCommand(text: String) {
        commandMode = false
        main.removeCallbacks(cmdTimeout)
        val r = Commands.handle(this, text.lowercase(Locale.ROOT))
        val q = r.ask
        if (q != null) {
            // not a built-in command -> ask the AI brain, then speak the answer
            AiBrain.ask(this, q) { ans -> main.post { if (running) say(ans) { listenSoon(300) } } }
            return
        }
        say(r.text) { if (r.followUp) enterCommandMode(); listenSoon(300) }
    }

    // ---------- speaking ----------
    override fun onInit(code: Int) {
        val t = tts ?: return
        if (code != TextToSpeech.SUCCESS) return
        val ok = listOf(Locale.forLanguageTag("ta-LK"), Locale.forLanguageTag("ta-IN"), Locale.forLanguageTag("en-IN"))
            .firstOrNull {
                val r = t.setLanguage(it)
                r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            }
        if (ok == null) return
        t.setSpeechRate(0.95f)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { finishSpeak() } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { main.post { finishSpeak() } }
            override fun onError(id: String?, errorCode: Int) { main.post { finishSpeak() } }
        })
        ttsReady = true
    }

    private fun say(text: String, done: () -> Unit) {
        rec?.cancel()
        val t = tts
        if (t == null || !ttsReady) { done(); return }
        speaking = true
        onSpeakDone = done
        main.removeCallbacks(speakGuard)
        main.postDelayed(speakGuard, 15000)
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "piriya")
    }

    private fun finishSpeak() {
        main.removeCallbacks(speakGuard)
        speaking = false
        resumeAt = SystemClock.elapsedRealtime() + 600
        val d = onSpeakDone
        onSpeakDone = null
        d?.invoke()
    }

    // ---------- helpers ----------
    private fun acquireWakeLock() {
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "piriya:wake").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    /**
     * Android blocks background apps from opening other apps. A user-granted "display over other apps"
     * permission lifts that, but only while the app has a visible overlay - so keep a 1px invisible one.
     */
    private fun addOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return
        try {
            val v = View(this)
            val lp = WindowManager.LayoutParams(
                1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.START or Gravity.TOP }
            getSystemService(WindowManager::class.java).addView(v, lp)
            overlay = v
        } catch (e: Exception) { /* permission revoked / not allowed - commands still work while app is open */ }
    }

    private fun muteBeep(mute: Boolean) {
        if (!MUTE_BEEP) return
        try {
            val am = getSystemService(AudioManager::class.java)
            for (s in intArrayOf(AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM)) {
                am.adjustStreamVolume(s, if (mute) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE, 0)
            }
        } catch (e: Exception) { /* Do Not Disturb policy can block this - harmless */ }
    }

    override fun onDestroy() {
        running = false
        instance = null
        main.removeCallbacksAndMessages(null)
        rec?.destroy()
        offline?.stop()
        TamilAsr.release()
        tts?.stop(); tts?.shutdown()
        overlay?.let { try { getSystemService(WindowManager::class.java).removeView(it) } catch (e: Exception) {} }
        wakeLock?.let { if (it.isHeld) it.release() }
        muteBeep(false)
        super.onDestroy()
    }
}
