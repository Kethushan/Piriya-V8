package com.piriya.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var wakeSwitch: Switch
    private lateinit var engineSwitch: Switch
    private lateinit var dlBtn: Button
    private var downloading = false
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("piriya", MODE_PRIVATE) }
    private val tamil: Locale = Locale.forLanguageTag("ta-LK")

    private var askedRuntime = false
    private var askedOverlay = false
    private var askedBattery = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        tts = TextToSpeech(this, this)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        setupPermissions()
    }

    /** Tapping the "Wake word ON" notification (used after reboot) lands here. */
    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra("start_wake", false) == true) {
            prefs.edit().putBoolean("wake", true).apply()
            if (::wakeSwitch.isInitialized) wakeSwitch.isChecked = true
        }
    }

    // ---------- permissions ----------
    private fun runtimePerms(): List<String> = buildList {
        add(Manifest.permission.RECORD_AUDIO)
        add(Manifest.permission.CALL_PHONE)
        add(Manifest.permission.READ_CONTACTS)
        add(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun hasMic() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    /** Asks for everything one step at a time: normal permissions -> overlay -> battery -> start wake service. */
    private fun setupPermissions() {
        val missing = runtimePerms().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            if (!askedRuntime) {
                askedRuntime = true
                requestPermissions(missing.toTypedArray(), 10)
            }
            refreshStatus(); return
        }
        if (!Settings.canDrawOverlays(this) && !askedOverlay) {
            askedOverlay = true
            Toast.makeText(this, "'Display over other apps' ON பண்ணுங்க — background ல app open ஆக இது வேணும்", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName) && !askedBattery) {
            askedBattery = true
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
            return
        }
        if (prefs.getBoolean("wake", true) && hasMic() && !WakeService.isRunning) WakeService.start(this)
        ui.postDelayed({ refreshStatus() }, 900)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        setupPermissions()
    }

    // ---------- UI ----------
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(Color.rgb(11, 16, 32))
        }
        val title = TextView(this).apply {
            text = "PIRIYA"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Ready • தமிழ் பேசலாம்"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 18)
        }
        result = TextView(this).apply {
            text = "“வணக்கம்… என்ன செய்யணும்?”\n\n“Piriya” னு சொன்னா நானே எழுந்திருப்பேன்."
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(12, 20, 12, 20)
        }
        wakeSwitch = Switch(this).apply {
            text = "Wake word: “Piriya”  "
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("wake", true)
            setPadding(12, 12, 12, 12)
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean("wake", on).apply()
                if (on) {
                    askedOverlay = false; askedBattery = false
                    setupPermissions()
                } else {
                    WakeService.stop(this@MainActivity)
                    refreshStatus()
                }
            }
        }
        dlBtn = Button(this).apply { setOnClickListener { downloadEngine() } }
        engineSwitch = Switch(this).apply {
            text = "Own offline Tamil engine (no Google)  "
            setTextColor(Color.WHITE)
            setPadding(12, 12, 12, 12)
            isChecked = prefs.getBoolean("engine_offline", false) && TamilAsr.AVAILABLE && ModelStore.ready(this@MainActivity)
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean("engine_offline", on).apply()
                restartWake()
            }
        }
        val mic = Button(this).apply {
            text = "🎙  பேசு"
            textSize = 20f
            setOnClickListener {
                if (!hasMic()) { askedRuntime = false; setupPermissions(); return@setOnClickListener }
                val svc = WakeService.instance
                if (svc != null && svc.isOffline) { svc.armCommand(); return@setOnClickListener }
                svc?.pauseFor(20000)
                listen()
            }
        }
        val settingsBtn = Button(this).apply {
            text = "⚙ Piriya Settings"
            setOnClickListener { openSettings() }
        }
        root.addView(title)
        root.addView(status)
        root.addView(result, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(wakeSwitch)
        root.addView(engineSwitch)
        root.addView(dlBtn)
        val aiBtn = Button(this).apply { text = "🧠 AI key"; setOnClickListener { askKey() } }
        val accBtn = Button(this).apply {
            text = "♿ Access"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val asstBtn = Button(this).apply {
            text = "⭐ Assistant"
            setOnClickListener {
                try { startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) }
                catch (e: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            }
        }
        val homeBtn = Button(this).apply {
            text = "🏠 Home"
            setOnClickListener {
                try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
                catch (e: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            listOf(aiBtn, accBtn, asstBtn, homeBtn).forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
        }
        root.addView(row)
        root.addView(mic)
        root.addView(settingsBtn)
        setContentView(root)
    }

    private fun refreshEngineUi() {
        if (!::dlBtn.isInitialized) return
        when {
            !TamilAsr.AVAILABLE -> {
                dlBtn.text = "Offline engine இந்த build ல இல்ல"
                dlBtn.isEnabled = false; engineSwitch.isEnabled = false
            }
            ModelStore.ready(this) -> { dlBtn.visibility = View.GONE; engineSwitch.isEnabled = true }
            else -> {
                if (!downloading) dlBtn.text = "⬇ Tamil engine download (${ModelStore.SIZE_TEXT}, Wi-Fi)"
                dlBtn.isEnabled = !downloading; engineSwitch.isEnabled = false
            }
        }
    }

    private fun downloadEngine() {
        if (downloading) return
        downloading = true
        dlBtn.isEnabled = false
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Thread {
            var err: String? = null
            try {
                ModelStore.download(this) { p -> ui.post { dlBtn.text = "Downloading… $p%" } }
            } catch (e: Exception) {
                err = e.message ?: "download error"
            }
            ui.post { finishDownload(err) }
        }.start()
    }

    private fun finishDownload(err: String?) {
        downloading = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        refreshEngineUi()
        if (err == null) {
            Toast.makeText(this, "Tamil engine ready ✅", Toast.LENGTH_LONG).show()
            engineSwitch.isChecked = true   // listener saves the choice and restarts the wake service
        } else {
            status.text = "Download fail: $err"
        }
    }

    /** Restart the wake service so it picks up the newly chosen speech engine. */
    private fun restartWake() {
        if (!WakeService.isRunning) return
        WakeService.stop(this)
        ui.postDelayed({
            if (prefs.getBoolean("wake", true) && hasMic()) WakeService.start(this)
            refreshStatus()
        }, 800)
    }

    private fun refreshStatus() {
        if (!::status.isInitialized) return
        refreshEngineUi()
        status.text = when {
            !hasMic() -> "Microphone permission வேணும்"
            WakeService.isRunning && WakeService.instance?.isOffline == true -> "Wake ON • own Tamil engine 🎧"
            WakeService.isRunning -> "Wake ON • “Piriya” னு சொல்லுங்க 🎧"
            else -> "Ready • தமிழ் பேசலாம்"
        }
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) {
            val r = tts.setLanguage(tamil)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale.forLanguageTag("en-IN"))
            tts.setSpeechRate(0.95f)
        }
    }

    private fun speak(text: String) {
        status.text = "Piriya பேசுது…"
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "piriya")
        ui.postDelayed({ refreshStatus() }, 1800)
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("இந்த phone ல voice recognition available இல்லை.")
            return
        }
        recognizer?.destroy()
        val r = Recog.create(this)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ta-LK")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ta-LK")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { status.text = "கேட்கிறேன்… 🎧" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "புரிந்துகொள்கிறேன்…" }
            override fun onError(e: Int) {
                status.text = "மீண்டும் பேசலாம்"
                speak("சரியாக கேட்கவில்லை. இன்னொரு முறை சொல்லுங்க.")
            }
            override fun onResults(b: Bundle?) {
                val heard = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                result.text = "நீங்கள்: $heard"
                val cmd = Commands.stripWake(heard).ifBlank { heard.lowercase(Locale.ROOT) }
                val reply = Commands.handle(this@MainActivity, cmd)
                val q = reply.ask
                if (q != null) {
                    status.text = "யோசிக்கிறேன்… 🧠"
                    AiBrain.ask(this@MainActivity, q) { ans ->
                        ui.post { result.text = "நீங்கள்: $heard\n\n$ans"; status.text = "Ready • தமிழ் பேசலாம்"; speak(ans) }
                    }
                    return
                }
                speak(reply.text)
                if (reply.followUp) ui.postDelayed({ listen() }, 2500)
            }
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        r.startListening(intent)
        recognizer = r
    }

    private fun askKey() {
        val input = android.widget.EditText(this).apply {
            hint = "sk-ant-…"
            setSingleLine()
            setText(AiBrain.key(this@MainActivity))
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("AI brain • API key")
            .setMessage("Piriya க்கு தெரியாத கேள்விகளை AI க்கு அனுப்பும். Key இந்த phone ல மட்டும் இருக்கும். காலியா விட்டா AI OFF.")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                AiBrain.setKey(this, input.text.toString())
                Toast.makeText(this, if (AiBrain.enabled(this)) "AI brain ON" else "AI brain OFF", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        intent.data = Uri.parse("package:$packageName")
        startActivity(intent)
    }

    override fun onDestroy() {
        recognizer?.destroy()
        ui.removeCallbacksAndMessages(null)
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
