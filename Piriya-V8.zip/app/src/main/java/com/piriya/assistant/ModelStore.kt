package com.piriya.assistant

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Downloads the offline Tamil speech model (Whisper-small Tamil fine-tune, INT8, ~375 MB) once. */
object ModelStore {
    private const val BASE =
        "https://huggingface.co/ippocode/indic-asr-onnx/resolve/main/models/whisper-small-ta/"
    private val FILES = listOf("tokens.txt", "encoder.int8.onnx", "decoder.int8.onnx")
    private const val TOTAL = 375_000_000L
    const val SIZE_TEXT = "375 MB"

    fun dir(ctx: Context): File = File(ctx.filesDir, "tamil-asr").apply { mkdirs() }

    fun ready(ctx: Context): Boolean = FILES.all { File(dir(ctx), it).length() > 100_000 }

    /** Blocking - call from a background thread. Throws IOException on failure. */
    @Throws(IOException::class)
    fun download(ctx: Context, onProgress: (Int) -> Unit) {
        val d = dir(ctx)
        var done = 0L
        var last = -1
        for (name in FILES) {
            val out = File(d, name)
            if (out.length() > 100_000) { done += out.length(); continue }
            val tmp = File(d, "$name.part")
            val c = URL("$BASE$name?download=true").openConnection() as HttpURLConnection
            c.connectTimeout = 20_000
            c.readTimeout = 30_000
            try {
                if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode} ($name)")
                c.inputStream.use { input ->
                    FileOutputStream(tmp).use { o ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            o.write(buf, 0, n)
                            done += n
                            val pct = minOf(99, (done * 100 / TOTAL).toInt())
                            if (pct != last) { last = pct; onProgress(pct) }
                        }
                    }
                }
            } finally {
                c.disconnect()
            }
            if (!tmp.renameTo(out)) throw IOException("rename failed ($name)")
        }
        onProgress(100)
    }
}
