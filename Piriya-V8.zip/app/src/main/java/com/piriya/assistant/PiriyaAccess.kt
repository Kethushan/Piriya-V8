package com.piriya.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Lets Piriya control other apps by voice: Back / Home / Recents / Notifications / Screenshot,
 * scrolling, and tapping an on-screen button by its visible text.
 * It only acts when a spoken command asks for it; nothing on screen is stored or sent anywhere.
 */
class PiriyaAccess : AccessibilityService() {

    companion object {
        @Volatile var instance: PiriyaAccess? = null
    }

    override fun onServiceConnected() { instance = this; WakeService.ensureRunning(this) }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun global(action: Int): Boolean = performGlobalAction(action)

    /** forward = content moves up (like "scroll down"). */
    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findScrollable(root) ?: return false
        return node.performAction(
            if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        )
    }

    private fun findScrollable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            findScrollable(c)?.let { return it }
        }
        return null
    }

    /** Clicks the first clickable element whose text / description contains [text]. */
    fun tap(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(text)) {
            var x: AccessibilityNodeInfo? = n
            while (x != null) {
                if (x.isClickable && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                x = x.parent
            }
        }
        return false
    }
}
