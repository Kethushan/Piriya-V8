package com.piriya.assistant

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Own microphone loop (no Google speech service): simple energy VAD cuts the audio into utterances,
 * each utterance is transcribed on-device by [TamilAsr]. Text is delivered on the main thread.
 */
class OfflineListener(
    private val isCommand: () -> Boolean,
    private val isPaused: () -> Boolean,
    private val onText: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private val decoder = Executors.newSingleThreadExecutor()
    private val pending = AtomicInteger(0)
    @Volatile private var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "piriya-mic").also { it.start() }
    }

    fun stop() {
        running = false
        thread?.interrupt()
        decoder.shutdownNow()
    }

    @Suppress("MissingPermission")
    private fun loop() {
        val rate = 16000
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, rate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf, rate * 2)
            )
        } catch (e: Throwable) { running = false; return }
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); running = false; return }

        val frame = ShortArray(320)              // 20 ms
        val seg = ShortArray(rate * 12)          // longest utterance: 12 s
        val pre = ArrayDeque<ShortArray>()       // 300 ms pre-roll so the first syllable isn't cut
        var n = 0
        var speech = false
        var voiced = 0
        var silence = 0
        var noise = 300.0

        rec.startRecording()
        try {
            while (running) {
                val got = rec.read(frame, 0, frame.size)
                if (got <= 0) continue
                if (isPaused()) { speech = false; n = 0; voiced = 0; silence = 0; pre.clear(); continue }

                var sum = 0.0
                for (i in 0 until got) sum += frame[i].toDouble() * frame[i]
                val rms = sqrt(sum / got)
                val loud = rms > max(450.0, noise * 2.5)

                if (!speech) {
                    if (loud) voiced++ else { voiced = 0; noise = noise * 0.97 + rms * 0.03 }
                    pre.addLast(frame.copyOf(got))
                    if (pre.size > 15) pre.removeFirst()
                    if (voiced >= 4) {
                        speech = true; silence = 0; n = 0
                        for (f in pre) { System.arraycopy(f, 0, seg, n, f.size); n += f.size }
                        pre.clear()
                    }
                } else {
                    if (n + got <= seg.size) { System.arraycopy(frame, 0, seg, n, got); n += got }
                    if (loud) silence = 0 else silence++
                    val ms = n / 16
                    val cmd = isCommand()
                    val limit = if (cmd) 10_000 else 6_000
                    if (silence >= 30 || ms >= limit) {
                        val speechMs = ms - silence * 20
                        // in wake-word mode very long speech is conversation / TV, not "Piriya ..." - ignore it
                        val tooLong = ms >= limit && !cmd
                        if (speechMs >= 350 && !tooLong) submit(seg.copyOf(n))
                        speech = false; n = 0; voiced = 0; silence = 0
                    }
                }
            }
        } finally {
            try { rec.stop() } catch (_: Exception) {}
            rec.release()
        }
    }

    private fun submit(pcm: ShortArray) {
        if (pending.get() >= 2) return           // decoder busy: drop instead of piling up
        val f = FloatArray(pcm.size) { pcm[it] / 32768f }
        pending.incrementAndGet()
        try {
            decoder.execute {
                try {
                    val t = TamilAsr.recognize(f)
                    if (t.isNotBlank()) main.post { onText(t) }
                } finally {
                    pending.decrementAndGet()
                }
            }
        } catch (e: Exception) {
            pending.decrementAndGet()
        }
    }
}
