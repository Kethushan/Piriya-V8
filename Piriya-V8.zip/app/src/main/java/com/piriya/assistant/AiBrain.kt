package com.piriya.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Online "brain" for questions that are not a built-in command.
 * The API key is typed into the app (never hard-coded) and kept only in this app's private storage.
 */
object AiBrain {
    private const val MODEL = "claude-haiku-4-5-20251001"
    private const val SYSTEM =
        "நீ Piriya, ஒரு தமிழ் voice assistant. எப்போதும் தமிழில் (தேவைப்பட்டால் சில English வார்த்தைகள்) " +
        "1-2 சின்ன வாக்கியங்களில் பதில் சொல்லு. பதில் சத்தமாக வாசிக்கப்படும், அதனால் markdown, emoji, " +
        "பட்டியல், குறியீடுகள் வேண்டாம்."

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("piriya", Context.MODE_PRIVATE)
    fun key(ctx: Context): String = prefs(ctx).getString("ai_key", "")?.trim().orEmpty()
    fun enabled(ctx: Context) = key(ctx).isNotEmpty()
    fun setKey(ctx: Context, k: String) = prefs(ctx).edit().putString("ai_key", k.trim()).apply()

    /** Runs on a background thread; [done] is called from that thread with the spoken answer. */
    fun ask(ctx: Context, question: String, done: (String) -> Unit) {
        val k = key(ctx)
        Thread {
            val answer = try { call(k, question) } catch (e: Exception) { "இப்போ AI ஐ அடைய முடியவில்லை. Internet பாருங்க." }
            done(answer)
        }.start()
    }

    private fun call(key: String, q: String): String {
        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 10_000
        conn.readTimeout = 30_000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-api-key", key)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 300)
            .put("system", SYSTEM)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", q)))
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        if (code !in 200..299) {
            conn.errorStream?.close()
            return when (code) {
                401, 403 -> "API key சரியில்லை. Piriya app ல key ஐ மாத்துங்க."
                429 -> "கொஞ்ச நேரம் கழிச்சு கேளுங்க."
                else -> "AI error $code."
            }
        }
        val text = conn.inputStream.bufferedReader().use { it.readText() }
        val blocks = JSONObject(text).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until blocks.length()) {
            val b = blocks.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.optString("text"))
        }
        return sb.toString().trim().ifBlank { "பதில் கிடைக்கவில்லை." }
    }
}
