package com.piriya.assistant

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import android.Manifest

/** Makes Piriya selectable as the phone's default digital assistant (power-button long-press / assist gesture). */
class PiriyaVoiceService : VoiceInteractionService() {
    override fun onReady() { super.onReady(); WakeService.ensureRunning(this) }
}

class PiriyaSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = PiriyaSession(this)
}

class PiriyaSession(ctx: Context) : VoiceInteractionSession(ctx) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        val c = context
        if (c.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            c.startActivity(Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } else {
            val svc = WakeService.instance
            if (svc != null) svc.armCommand()
            else {
                WakeService.start(c)
                Handler(Looper.getMainLooper()).postDelayed({ WakeService.instance?.armCommand() }, 1500)
            }
        }
        hide()
    }
}

/**
 * Android expects an assistant to declare a speech-recognition service. Piriya does its own listening,
 * so this is only a placeholder that reports an error if anything ever asks it to recognise speech.
 */
class PiriyaRecognitionService : RecognitionService() {
    override fun onStartListening(intent: Intent?, cb: Callback?) { cb?.error(SpeechRecognizer.ERROR_CLIENT) }
    override fun onCancel(cb: Callback?) {}
    override fun onStopListening(cb: Callback?) {}
}

/** Always use Google's recognizer for Piriya's own listening, even if Piriya is chosen as the system assistant. */
object Recog {
    fun create(ctx: Context): SpeechRecognizer {
        val g = ctx.packageManager
            .queryIntentServices(Intent(RecognitionService.SERVICE_INTERFACE), 0)
            .firstOrNull { it.serviceInfo.packageName == "com.google.android.googlequicksearchbox" }
        return if (g != null)
            SpeechRecognizer.createSpeechRecognizer(ctx, ComponentName(g.serviceInfo.packageName, g.serviceInfo.name))
        else SpeechRecognizer.createSpeechRecognizer(ctx)
    }
}
