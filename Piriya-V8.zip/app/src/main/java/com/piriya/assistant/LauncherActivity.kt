package com.piriya.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import java.util.Locale

/**
 * Piriya as the phone's home screen: clock, app search, app grid and a big "Piriya" mic button.
 * Set it as default from the app (🏠 Home). Switch back any time in Settings -> Default apps -> Home app.
 */
class LauncherActivity : Activity() {

    private class Item(val label: String, val pkg: String, val icon: Drawable)

    private var all: List<Item> = emptyList()
    private var shown: List<Item> = emptyList()
    private lateinit var grid: GridView
    private lateinit var search: EditText
    private val ui = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val adapter = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(i: Int) = shown[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, convert: View?, parent: ViewGroup?): View {
            val cell = (convert as? LinearLayout) ?: LinearLayout(this@LauncherActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(2), dp(6), dp(2), dp(6))
                addView(ImageView(context), LinearLayout.LayoutParams(dp(48), dp(48)))
                addView(TextView(context).apply {
                    textSize = 12f
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setPadding(0, dp(4), 0, 0)
                })
            }
            val item = shown[i]
            (cell.getChildAt(0) as ImageView).setImageDrawable(item.icon)
            (cell.getChildAt(1) as TextView).text = item.label
            return cell
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(11, 16, 32))
            setPadding(dp(16), dp(36), dp(16), dp(12))
        }
        val clock = TextClock(this).apply {
            format12Hour = "h:mm"; format24Hour = "H:mm"
            textSize = 52f
            setTextColor(Color.WHITE)
        }
        val date = TextClock(this).apply {
            format12Hour = "EEEE, d MMM"; format24Hour = "EEEE, d MMM"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, dp(12))
        }
        search = EditText(this).apply {
            hint = "🔍 App தேடு"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_GO
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { applyFilter() }
                override fun afterTextChanged(s: Editable?) {}
            })
            setOnEditorActionListener { _, _, _ -> shown.firstOrNull()?.let { open(it) }; true }
        }
        grid = GridView(this).apply {
            numColumns = 4
            verticalSpacing = dp(8)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            setSelector(ColorDrawable(Color.TRANSPARENT))
            adapter = this@LauncherActivity.adapter
            setOnItemClickListener { _, _, i, _ -> open(shown[i]) }
            setOnItemLongClickListener { _, _, i, _ ->
                // long-press an app -> its App info page (uninstall / permissions)
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${shown[i].pkg}"))
                )
                true
            }
        }
        val mic = Button(this).apply {
            text = "🎙  Piriya"
            textSize = 18f
            setOnClickListener { talk() }
        }
        val cfg = Button(this).apply {
            text = "⚙"
            setOnClickListener { startActivity(Intent(this@LauncherActivity, MainActivity::class.java)) }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(mic, LinearLayout.LayoutParams(0, -2, 1f))
            addView(cfg, LinearLayout.LayoutParams(-2, -2))
        }
        root.addView(clock)
        root.addView(date)
        root.addView(search)
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bar)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        // home screen is always in front after boot / unlock, so this is a reliable place to start the wake word
        val wake = getSharedPreferences("piriya", MODE_PRIVATE).getBoolean("wake", true)
        if (wake && hasMic() && !WakeService.isRunning) WakeService.start(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        search.setText("")
        grid.setSelection(0)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        // a home screen never closes; back just clears the search box
        if (search.text.isNotEmpty()) search.setText("")
    }

    private fun hasMic() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun talk() {
        if (!hasMic()) { startActivity(Intent(this, MainActivity::class.java)); return }
        val svc = WakeService.instance
        if (svc != null) svc.armCommand()
        else {
            WakeService.start(this)
            ui.postDelayed({ WakeService.instance?.armCommand() }, 1500)
        }
    }

    private fun open(item: Item) {
        val i = packageManager.getLaunchIntentForPackage(item.pkg) ?: return
        search.setText("")
        startActivity(i)
    }

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val list = pm.queryIntentActivities(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
            )
                .map { Item(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase(Locale.ROOT) }
            ui.post { all = list; applyFilter() }
        }.start()
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase(Locale.ROOT)
        shown = if (q.isEmpty()) all else all.filter { it.label.lowercase(Locale.ROOT).contains(q) }
        adapter.notifyDataSetChanged()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
