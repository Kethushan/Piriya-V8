package com.piriya.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings

/**
 * "Piriya setup" - Android does not allow any app to switch these permissions on by itself, so Piriya
 * opens the next missing screen, tells you what to tap, and you say "Piriya setup" again for the next one.
 */
object Setup {
    private const val AGAIN = " முடிஞ்சதும் Piriya setup னு திரும்ப சொல்லுங்க."

    private fun open(ctx: Context, i: Intent) = ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    fun next(ctx: Context): Commands.Reply {
        val pkg = ctx.packageName
        val prefs = ctx.getSharedPreferences("piriya", Context.MODE_PRIVATE)

        if (!Settings.canDrawOverlays(ctx)) {
            open(ctx, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$pkg")))
            return Commands.Reply("Piriya க்கு Display over other apps ஐ ON பண்ணுங்க.$AGAIN")
        }
        val pm = ctx.getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(pkg)) {
            open(ctx, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$pkg")))
            return Commands.Reply("Battery optimization ல Allow தட்டுங்க.$AGAIN")
        }
        if (PiriyaAccess.instance == null) {
            open(ctx, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return Commands.Reply("Accessibility ல Piriya ஐ தேடி ON பண்ணுங்க.$AGAIN")
        }
        if (!isAssistant(ctx) && !prefs.getBoolean("asked_assistant", false)) {
            prefs.edit().putBoolean("asked_assistant", true).apply()
            try { open(ctx, Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) }
            catch (e: Exception) { open(ctx, Intent(Settings.ACTION_SETTINGS)) }
            return Commands.Reply("Digital assistant app ஆ Piriya ஐ தேர்ந்தெடுங்க.$AGAIN")
        }
        if (!isHome(ctx) && !prefs.getBoolean("asked_home", false)) {
            prefs.edit().putBoolean("asked_home", true).apply()
            try { open(ctx, Intent(Settings.ACTION_HOME_SETTINGS)) }
            catch (e: Exception) { open(ctx, Intent(Settings.ACTION_SETTINGS)) }
            return Commands.Reply("Home app ஆ Piriya ஐ தேர்ந்தெடுங்க.$AGAIN")
        }
        return Commands.Reply("எல்லாம் ready! இனி பட்டன் தேவையில்லை, Piriya னு சொன்னா போதும்.")
    }

    private fun isAssistant(ctx: Context): Boolean = try {
        Settings.Secure.getString(ctx.contentResolver, "assistant")?.startsWith(ctx.packageName + "/") == true
    } catch (e: Exception) { false }

    private fun isHome(ctx: Context): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val r = ctx.packageManager.resolveActivity(i, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
        return r?.activityInfo?.packageName == ctx.packageName
    }
}
