package com.piriya.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.accessibilityservice.AccessibilityService
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** All voice commands live here so MainActivity (mic button) and WakeService (wake word) share them. */
object Commands {

    data class Reply(val text: String, val followUp: Boolean = false, val ask: String? = null)

    // ---------- wake word ----------
    private val WAKE = listOf(
        "piriya", "priya", "priyaa", "piriyaa", "pirya", "piria",
        "பிரியா", "பிரிய", "ப்ரியா", "ப்ரிய"
    ).sortedByDescending { it.length }

    fun hasWake(s: String): Boolean {
        val t = s.lowercase(Locale.ROOT)
        return WAKE.any { t.contains(it) }
    }

    fun stripWake(s: String): String {
        var t = s.lowercase(Locale.ROOT)
        WAKE.forEach { t = t.replace(it, " ") }
        t = t.replace(Regex("\\b(hey|hi|ok|okay)\\b"), " ").replace("ஹே", " ")
        return t.replace(Regex("\\s+"), " ").trim()
    }

    // ---------- entry point ----------
    fun handle(ctx: Context, c: String): Reply = try {
        route(ctx, c)
    } catch (e: Exception) {
        Reply("இந்த command செய்ய முடியவில்லை.")
    }

    private fun has(s: String, vararg k: String) = k.any { s.contains(it) }

    private fun go(ctx: Context, i: Intent) = ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    private fun route(ctx: Context, c: String): Reply = when {
        c.isBlank() -> Reply("சொல்லுங்க, கேட்கிறேன்.", true)
        has(c, "setup", "set up", "செட்டப்") -> Setup.next(ctx)
        isAccess(c) -> access(ctx, c)
        has(c, "youtube", "யூடியூப்", "யூட்யூப்") -> launch(ctx, "com.google.android.youtube", "YouTube")
        has(c, "chrome", "browser", "குரோம்") -> launch(ctx, "com.android.chrome", "Chrome")
        has(c, "flash", "torch", "லைட்", "டார்ச்") -> torch(ctx, !has(c, "off", "அணை", "நிறுத்து"))
        has(c, "camera", "கேமரா") -> {
            go(ctx, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); Reply("Camera open பண்ணிட்டேன்.")
        }
        has(c, "volume up", "volume increase", "சத்தம் கூட்டு", "வால்யூம் கூட்டு") -> volume(ctx, true)
        has(c, "volume down", "volume decrease", "சத்தம் குறை", "வால்யூம் குறை") -> volume(ctx, false)
        has(c, "wifi", "wi-fi", "வைஃபை", "வைபை") -> settings(ctx, Settings.ACTION_WIFI_SETTINGS, "WiFi settings")
        has(c, "bluetooth", "ப்ளூடூத்", "புளூடூத்") -> settings(ctx, Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth settings")
        has(c, "brightness", "பிரைட்னஸ்") -> settings(ctx, Settings.ACTION_DISPLAY_SETTINGS, "Display settings")
        has(c, "settings", "setting", "அமைப்புகள்", "செட்டிங்") -> settings(ctx, Settings.ACTION_SETTINGS, "Settings")
        has(c, "alarm", "அலாரம்") -> {
            go(ctx, Intent(AlarmClock.ACTION_SET_ALARM)); Reply("Alarm open பண்ணிட்டேன்.")
        }
        has(c, "timer", "டைமர்") -> timer(ctx, c)
        has(c, "what time", "current time", "நேரம்", "மணி என்ன") || c.trim() == "time" ->
            Reply("இப்போ நேரம் " + SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date()))
        has(c, "call", "phone", "dial", "அழைப்பு", "கால்") -> call(ctx, c)
        has(c, "search", "தேடு", "google", "கூகுள்") -> search(ctx, c)
        has(c, "help", "என்ன செய்யலாம்", "what can you do") -> Reply(
            "நான் Piriya setup, YouTube, Chrome, camera, flashlight, settings, WiFi, Bluetooth, volume, alarm, timer, நேரம், " +
                "contact க்கு call, web search, மற்றும் phone ல இருக்கிற எந்த app ஐயும் open செய்ய முடியும்."
        )
        else -> openApp(ctx, c)
            ?: if (AiBrain.enabled(ctx)) Reply("", ask = c)
            else Reply("நான் புரிந்தது: $c. இந்த command க்கு இன்னும் action add செய்யவில்லை. (AI key சேர்த்தா எல்லா கேள்விக்கும் பதில் சொல்வேன்.)")
    }

    // ---------- control other apps (Accessibility service) ----------
    private val TAP_EN = Regex("\\b(tap|click|press)\\b")
    private val TAP_TA = listOf("தட்டு", "தொடு", "அழுத்து")

    private fun isTap(c: String) = TAP_EN.containsMatchIn(c) || TAP_TA.any { c.contains(it) }

    private fun isAccess(c: String) = isTap(c) || has(
        c, "go back", "back button", "பின்னாடி", "பின்னால்", "go home", "home screen", "ஹோம்",
        "recent apps", "recents", "notification", "நோட்டிபிகேஷன்", "scroll", "ஸ்க்ரோல்", "screenshot", "ஸ்கிரீன்ஷாட்"
    )

    private fun access(ctx: Context, c: String): Reply {
        val a = PiriyaAccess.instance ?: run {
            go(ctx, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return Reply("Accessibility settings ல Piriya ஐ ON பண்ணுங்க.")
        }
        return when {
            has(c, "screenshot", "ஸ்கிரீன்ஷாட்") ->
                if (Build.VERSION.SDK_INT >= 28) {
                    a.global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT); Reply("Screenshot எடுத்துட்டேன்.")
                } else Reply("இந்த Android version ல screenshot வசதி இல்லை.")
            has(c, "recent", "recents") -> { a.global(AccessibilityService.GLOBAL_ACTION_RECENTS); Reply("Recent apps காட்டுறேன்.") }
            has(c, "notification", "நோட்டிபிகேஷன்") -> { a.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS); Reply("Notifications காட்டுறேன்.") }
            has(c, "go home", "home screen", "ஹோம்") -> { a.global(AccessibilityService.GLOBAL_ACTION_HOME); Reply("Home போறேன்.") }
            has(c, "go back", "back button", "பின்னாடி", "பின்னால்") -> { a.global(AccessibilityService.GLOBAL_ACTION_BACK); Reply("பின்னாடி போறேன்.") }
            has(c, "scroll", "ஸ்க்ரோல்") -> {
                val up = !has(c, "down", "கீழ") && has(c, "up", "மேல")
                if (a.scroll(!up)) Reply(if (up) "மேல scroll பண்ணிட்டேன்." else "கீழ scroll பண்ணிட்டேன்.")
                else Reply("Scroll பண்ண முடியல.")
            }
            else -> {
                var t = TAP_EN.replace(c, " ")
                TAP_TA.forEach { t = t.replace(it, " ") }
                t = t.replace(Regex("\\b(on|the|button)\\b"), " ").replace("பட்டனை", " ").replace("பட்டன்", " ")
                t = t.replace(Regex("\\s+"), " ").trim()
                when {
                    t.isBlank() -> Reply("எதை தொடணும்? பெயர் சொல்லுங்க.", true)
                    a.tap(t) -> Reply("$t தொட்டுட்டேன்.")
                    else -> Reply("Screen ல $t கிடைக்கவில்லை.")
                }
            }
        }
    }

    // ---------- actions ----------
    private fun launch(ctx: Context, pkg: String, name: String): Reply {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
            ?: return Reply("$name இந்த phone ல கிடைக்கவில்லை.")
        go(ctx, i)
        return Reply("$name open பண்ணிட்டேன்.")
    }

    private fun settings(ctx: Context, action: String, name: String): Reply {
        go(ctx, Intent(action)); return Reply("$name open பண்ணிட்டேன்.")
    }

    private fun volume(ctx: Context, up: Boolean): Reply {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI
        )
        return Reply(if (up) "Volume கூட்டிட்டேன்." else "Volume குறைச்சிட்டேன்.")
    }

    private fun torch(ctx: Context, on: Boolean): Reply {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return Reply("Flash இந்த phone ல இல்லை.")
        cm.setTorchMode(id, on)
        return Reply(if (on) "Flashlight போட்டுட்டேன்." else "Flashlight அணைச்சிட்டேன்.")
    }

    private fun timer(ctx: Context, c: String): Reply {
        val n = Regex("\\d+").find(c)?.value?.toIntOrNull()
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
        if (n != null && n in 1..1440) {
            val inSeconds = has(c, "second", "sec", "விநாடி", "வினாடி")
            i.putExtra(AlarmClock.EXTRA_LENGTH, if (inSeconds) n else n * 60)
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            go(ctx, i)
            return Reply(if (inSeconds) "$n விநாடி timer set பண்ணிட்டேன்." else "$n நிமிட timer set பண்ணிட்டேன்.")
        }
        go(ctx, i)
        return Reply("Timer open பண்ணிட்டேன்.")
    }

    private fun search(ctx: Context, c: String): Reply {
        val q = c.replace(Regex("search|google|தேடு|கூகுள்"), " ").replace(Regex("\\s+"), " ").trim().ifBlank { c }
        try {
            go(ctx, Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", q))
        } catch (e: Exception) {
            go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        }
        return Reply("$q தேடுறேன்.")
    }

    private val CALL_STOP = setOf(
        "call", "phone", "dial", "அழைப்பு", "கால்", "பண்ணு", "பண்ணுங்க", "பண்ணுங்கோ", "பண்ணுங்கள்",
        "செய்", "செய்யுங்க", "எடு", "எடுங்க", "ku", "to", "please", "பிளீஸ்", "க்கு", "கு"
    )

    private fun call(ctx: Context, c: String): Reply {
        val tokens = c.split(Regex("\\s+")).filter { it.isNotBlank() && it !in CALL_STOP }
            .map { it.removeSuffix("க்கு").removeSuffix("கு") }.filter { it.isNotBlank() }
        if (tokens.isEmpty()) return Reply("யாருக்கு call பண்ணணும்? பெயர் சொல்லுங்க.", true)

        // a spoken/typed number
        val digits = tokens.joinToString("").filter { it.isDigit() || it == '+' }
        if (digits.length >= 6) return dial(ctx, digits, digits)

        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            return Reply("Contacts permission கொடுங்க.")

        val queries = listOf(tokens.joinToString(" ")) + tokens.filter { it.length >= 2 }
        for (q in queries) {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$q%"), null
            )?.use { cur ->
                if (cur.moveToFirst()) return dial(ctx, cur.getString(1), cur.getString(0))
            }
        }
        return Reply("${tokens.joinToString(" ")} contact கிடைக்கவில்லை.")
    }

    private fun dial(ctx: Context, number: String, label: String): Reply {
        val uri = Uri.fromParts("tel", number, null)
        val granted = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        go(ctx, Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri))
        return Reply("$label க்கு call பண்றேன்.")
    }

    private val ALIAS = mapOf(
        "வாட்ஸ்அப்" to "whatsapp", "வாட்சப்" to "whatsapp", "பேஸ்புக்" to "facebook",
        "இன்ஸ்டாகிராம்" to "instagram", "டெலிகிராம்" to "telegram", "மேப்ஸ்" to "maps",
        "ஜிமெயில்" to "gmail", "கால்குலேட்டர்" to "calculator", "கேலரி" to "gallery",
        "ஸ்னாப்சாட்" to "snapchat", "மெசேஞ்சர்" to "messenger", "டிக்டாக்" to "tiktok"
    )

    /** Opens any installed app whose label appears in the spoken text. */
    private fun openApp(ctx: Context, c: String): Reply? {
        var t = c
        ALIAS.forEach { (k, v) -> t = t.replace(k, v) }
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val hit = pm.queryIntentActivities(launcher, 0)
            .map { it to it.loadLabel(pm).toString().lowercase(Locale.ROOT) }
            .filter { it.second.length >= 3 && t.contains(it.second) }
            .maxByOrNull { it.second.length } ?: return null
        val i = pm.getLaunchIntentForPackage(hit.first.activityInfo.packageName) ?: return null
        go(ctx, i)
        return Reply("${hit.first.loadLabel(pm)} open பண்ணிட்டேன்.")
    }
}
