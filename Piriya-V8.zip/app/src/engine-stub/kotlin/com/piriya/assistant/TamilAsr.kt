package com.piriya.assistant

import android.content.Context

/** Stub used when sherpa-onnx was not bundled into this build: the app falls back to Google speech. */
object TamilAsr {
    const val AVAILABLE = false
    @Suppress("UNUSED_PARAMETER") fun load(ctx: Context): Boolean = false
    @Suppress("UNUSED_PARAMETER") fun recognize(samples: FloatArray): String = ""
    fun release() {}
}
